import java.lang.invoke.SwitchPoint;
import java.util.Scanner;

public class Main {
    public static Scanner cr= new Scanner(System.in);
    public static void main(String[] args) {
        Clase logica = new Clase();


        int cantEst=cr.nextInt();
        Estudiantes [] estudiantes=new Estudiantes[cantEst];
        Estudiantes juan = new Estudiantes("Juan Moreno","ING. Sistemas",1,1081733765,4.3);
        Estudiantes luis = new Estudiantes("Luis Hernandez","ING. Sistemas",2,108355654,2.4);
        Estudiantes ana = new Estudiantes("Ana Muñoz","ING. Agroecológica",3,1097666543,3.0);
        Estudiantes liseth = new Estudiantes("Liseth Parra","ING. Alimentos",4,1081665001,2.5);
        Estudiantes jorge = new Estudiantes("Jorge Gonzales","ING. Alimentos",5,1071554527,4.0);
        Estudiantes arnold = new Estudiantes("Arnold Camacho","ING. Sistemas",6,1080999998,4.5);

        estudiantes[0]=juan;
        estudiantes[1]=luis;
        estudiantes[2]=ana;
        estudiantes[3]=liseth;
        estudiantes[4]=jorge;
        estudiantes[5]=arnold;

        logica.estudiantes=estudiantes;
        logica.docente="Julian Camilo Guevara Sanchez";
        logica.nombre="Lógica";

        System.out.println(logica);
        System.out.println(logica.ConsultarEst(1));
        System.out.println(logica.ConsultarEstId(1081665001));
        System.out.println(logica.modificarEst(1081733765,"Juan Moreno","Ing. Sistemas",1,1081733765,5.0));
        System.out.println(logica.ConsultarEstId(1081733765));
        System.out.println(logica.EliminarEst(1080999998));
        System.out.println(logica.ConsultarEstId(1080999998));
        System.out.println(logica.CantEstudiantes());





    }
    /*public void Menu(){
        System.out.println("Digite su opción:");
        System.out.println("----------------------");
        System.out.println("-1. Matricular estudiante-");
        System.out.println("-1. Consultar estudiante-");
        System.out.println("-1. Eliminar estudiante-");
        System.out.println("-1. Actualizar información estudiante-");
    }*/
}

