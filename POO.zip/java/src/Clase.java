import java.util.Arrays;

public class Clase {
    public Estudiantes estudiantes[];
    public String nombre;
    public String docente;
    public int num_estudiantes;

    public Clase(Estudiantes[] estudiantes, String nombre, String docente, int num_estudiantes) {
        this.estudiantes = estudiantes;
        this.nombre = nombre;
        this.docente = docente;
        this.num_estudiantes = num_estudiantes;
    }

    public Clase() {
        this.estudiantes = estudiantes;
        this.nombre = nombre;
        this.docente = docente;
        this.num_estudiantes = num_estudiantes;
    }

    public Estudiantes[] getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(Estudiantes[] estudiantes) {
        this.estudiantes = estudiantes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDocente() {
        return docente;
    }

    public void setDocente(String docente) {
        this.docente = docente;
    }

    public int getNum_estudiantes() {
        return num_estudiantes;
    }

    public void setNum_estudiantes(int num_estudiantes) {
        this.num_estudiantes = num_estudiantes;
    }

    public int CantEstudiantes(){
        int cant=0;
        for (int i = 0; i < estudiantes.length; i++) {
            if (estudiantes[i]!=null){
                cant++;
            }
        }
        return cant;
    }

    public String ConsultarEst(int codigo){
        String srt="";
        for (int i = 0; i < estudiantes.length; i++) {
            if(estudiantes[i]!=null && estudiantes[i].getCodigo()==codigo){
                srt=estudiantes[i].toString();
            }
        }
        return srt;
    }
    public String ConsultarEstId(float identificacion){
        String srt="";
        for (int i = 0; i < estudiantes.length; i++) {
            if(estudiantes[i]!=null && estudiantes[i].getIdentificacion()==identificacion){
                srt=estudiantes[i].toString();
            }
        }
        return srt;
    }

    public boolean modificarEst(float id,String nombre, String programa, int codigo, float identificacion, double promedio){
        boolean bandera=false;
        for (int i = 0; i < estudiantes.length; i++) {
            if(estudiantes[i]!=null && estudiantes[i].getIdentificacion()==id){
                estudiantes[i].setIdentificacion(identificacion);
                estudiantes[i].setNombre(nombre);
                estudiantes[i].setPrograma(programa);
                estudiantes[i].setCodigo(codigo);
                estudiantes[i].setPromedio(promedio);
                bandera=true;
            }
        }
        return bandera;
    }

    public boolean EliminarEst(float id){
        boolean bandera=false;
        for (int i = 0; i < estudiantes.length; i++) {
            if (estudiantes[i] != null && estudiantes[i].getIdentificacion() == id) {
                estudiantes[i] = null;
                bandera= true;
            }
        }
        return bandera;
    }



    @Override
    public String toString() {
        return
                ", nombre='" + nombre + "\n" +
                ", docente='" + docente + "\n" +
                ", Cant. Estudiantes=" + CantEstudiantes() + "\n\n"+
                        "estudiantes: " + Arrays.toString(estudiantes) +"\n";
    }
}
