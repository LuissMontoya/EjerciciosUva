public class Estudiantes {
    private String nombre;
    private String programa;
    private int codigo;
    private float identificacion;
    private double promedio;

    public Estudiantes(String nombre, String programa, int codigo, float identificacion, double promedio) {
        this.nombre = nombre;
        this.programa = programa;
        this.codigo = codigo;
        this.identificacion = identificacion;
        this.promedio = promedio;
    }
    public Estudiantes() {
        this.nombre = nombre;
        this.programa = programa;
        this.codigo = codigo;
        this.identificacion = identificacion;
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPrograma() {
        return programa;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public float getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(float identificacion) {
        this.identificacion = identificacion;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return  "nombre='" + nombre + '\'' +
                ", programa='" + programa + '\'' +
                ", codigo=" + codigo +
                ", identificacion=" + identificacion +
                ", promedio=" + promedio +
                '}'+"\n";
    }
}
